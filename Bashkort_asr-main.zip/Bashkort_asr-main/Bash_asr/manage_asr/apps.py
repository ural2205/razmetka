from django.apps import AppConfig


class ManageAsrConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'manage_asr'
